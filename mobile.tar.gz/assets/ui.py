"""Интерфейс поверх игрового поля: кнопки верхней панели, HUD-статус и модальная
панель настроек. Не содержит игровой логики — только чтение состояния/настроек
и рисование, плюс построение раскладок, которые input_handler использует для
определения кликов.
"""

import math

import pygame

import config
from board import PLAYER_X, PLAYER_O
from game_state import STATUS_WIN, STATUS_DRAW
from renderer import board_pixel_size
from settings import (
    MODE_PVE,
    DIFFICULTY_NOVICE,
    DIFFICULTY_EASY,
    DIFFICULTY_MEDIUM,
    DIFFICULTY_HARD,
)

DIFFICULTY_LABELS = {
    DIFFICULTY_NOVICE: "Новичок",
    DIFFICULTY_EASY: "Лёгкая",
    DIFFICULTY_MEDIUM: "Средняя",
    DIFFICULTY_HARD: "Сложная",
}


def status_text(game_state):
    if game_state.status == STATUS_WIN:
        symbol = "Крестики" if game_state.winner == PLAYER_X else "Нолики"
        return f"Победа: {symbol}"
    if game_state.status == STATUS_DRAW:
        return "Ничья"

    symbol = "Крестики" if game_state.current_player == PLAYER_X else "Нолики"
    return f"Ход: {symbol}"


def draw_hud_background(surface, width):
    rect = pygame.Rect(0, 0, width, config.HUD_HEIGHT)
    pygame.draw.rect(surface, config.COLOR_HUD_BACKGROUND, rect)


def draw_status_text(surface, font, game_state):
    text = status_text(game_state).upper()
    shadow = font.render(text, True, config.COLOR_HUD_TEXT_SHADOW)
    label = font.render(text, True, config.COLOR_TEXT)

    x = 14
    y = config.BUTTON_ROW_HEIGHT + config.STATUS_ROW_HEIGHT // 2 - label.get_height() // 2
    dx, dy = config.HUD_TEXT_SHADOW_OFFSET
    surface.blit(shadow, (x + dx, y + dy))
    surface.blit(label, (x, y))


def build_button_layout(settings, pending, game_state, font):
    """Строит раскладку кнопок верхней панели. Используется и для отрисовки,
    и для определения клика (input_handler) — раскладка должна быть одна и та же.

    `settings` — применённые (действующие) настройки, `pending` — то, что выбрано
    кнопками "Режим"/"Сложность", но ещё не подтверждено кнопкой "Применить".
    """
    buttons = []
    x = config.BUTTON_ROW_LEFT_MARGIN
    y = config.BUTTON_TOP_Y
    right_edge = board_pixel_size(settings.board_size) - config.BOARD_MARGIN

    def add_button(button_id, label, bg_color, text_color, glow_color=None, pos=None, icon=None, width=None):
        nonlocal x
        if width is None:
            text_width, _ = font.size(label)
            width = text_width + config.BUTTON_PADDING_X * 2
        button_x, button_y = pos if pos else (x, y)
        rect = pygame.Rect(button_x, button_y, width, config.BUTTON_HEIGHT)
        buttons.append(
            {
                "id": button_id,
                "rect": rect,
                "label": label,
                "bg_color": bg_color,
                "text_color": text_color,
                "glow_color": glow_color,
                "icon": icon,
            }
        )
        if pos is None:
            x += width + config.BUTTON_GAP

    add_button("restart", "Рестарт", config.COLOR_BUTTON_NEUTRAL, config.COLOR_BUTTON_NEUTRAL_TEXT)

    # "Настройки" — шестерёнка, открывает модальную панель с режимом/сложностью/переключателями
    add_button(
        "settings",
        "",
        config.COLOR_BUTTON_NEUTRAL,
        config.COLOR_BUTTON_NEUTRAL_TEXT,
        icon="gear",
        width=config.BUTTON_HEIGHT,
    )

    # "Отмена", "Сдаться" и "Выход" — одной группой у правого края верхнего ряда
    exit_label = "Выход"
    exit_width = font.size(exit_label)[0] + config.BUTTON_PADDING_X * 2
    exit_x = right_edge - exit_width

    surrender_label = "Сдаться"
    surrender_width = font.size(surrender_label)[0] + config.BUTTON_PADDING_X * 2
    surrender_x = exit_x - config.BUTTON_GAP - surrender_width

    # "Отмена" доступна в любом режиме (и PvP, и с ботом), если включена настройка allow_undo
    if settings.allow_undo:
        undo_size = config.BUTTON_HEIGHT
        undo_x = surrender_x - config.BUTTON_GAP - undo_size
        add_button(
            "undo",
            "",
            config.COLOR_BUTTON_NEUTRAL,
            config.COLOR_UNDO_ICON,
            pos=(undo_x, config.BUTTON_TOP_Y),
            icon="arrow_left",
            width=undo_size,
        )

    surrender_color = config.COLOR_PLAYER_X if game_state.current_player == PLAYER_X else config.COLOR_PLAYER_O
    add_button(
        "surrender",
        surrender_label,
        surrender_color,
        config.COLOR_SURRENDER_TEXT,
        pos=(surrender_x, config.BUTTON_TOP_Y),
    )
    add_button(
        "exit",
        exit_label,
        config.COLOR_BUTTON_EXIT,
        config.COLOR_BUTTON_EXIT_TEXT,
        glow_color=config.COLOR_BUTTON_EXIT_GLOW,
        pos=(exit_x, config.BUTTON_TOP_Y),
    )

    return buttons


def _draw_button_glow(surface, rect, color):
    max_extra = config.BUTTON_EXIT_GLOW_LAYERS[0][0]
    glow_rect = rect.inflate(max_extra * 2, max_extra * 2)
    glow_surface = pygame.Surface(glow_rect.size, pygame.SRCALPHA)

    for extra, alpha in config.BUTTON_EXIT_GLOW_LAYERS:
        layer_rect = pygame.Rect(0, 0, rect.width + extra * 2, rect.height + extra * 2)
        layer_rect.center = (glow_rect.width // 2, glow_rect.height // 2)
        pygame.draw.rect(glow_surface, (*color, alpha), layer_rect, border_radius=config.BUTTON_BORDER_RADIUS + 2)

    surface.blit(glow_surface, glow_rect.topleft)


def _draw_check_icon(surface, rect, color):
    cx, cy = rect.center
    size = min(rect.width, rect.height) * 0.28
    points = [
        (cx - size, cy),
        (cx - size * 0.25, cy + size * 0.75),
        (cx + size, cy - size * 0.6),
    ]
    pygame.draw.lines(surface, color, False, points, 3)


def _draw_arrow_left_icon(surface, rect, color):
    cx, cy = rect.center
    size = min(rect.width, rect.height) * 0.28
    pygame.draw.line(surface, color, (cx + size, cy), (cx - size, cy), 3)
    pygame.draw.line(surface, color, (cx - size, cy), (cx - size * 0.25, cy - size * 0.6), 3)
    pygame.draw.line(surface, color, (cx - size, cy), (cx - size * 0.25, cy + size * 0.6), 3)


def _draw_gear_icon(surface, rect, color):
    cx, cy = rect.center
    radius = min(rect.width, rect.height) * 0.2
    pygame.draw.circle(surface, color, (cx, cy), int(radius), 2)
    pygame.draw.circle(surface, color, (cx, cy), max(2, int(radius * 0.4)), 2)

    teeth = 8
    inner, outer = radius * 1.2, radius * 1.6
    for i in range(teeth):
        angle = 2 * math.pi * i / teeth
        x1, y1 = cx + inner * math.cos(angle), cy + inner * math.sin(angle)
        x2, y2 = cx + outer * math.cos(angle), cy + outer * math.sin(angle)
        pygame.draw.line(surface, color, (x1, y1), (x2, y2), 2)


def draw_buttons(surface, font, buttons):
    for button in buttons:
        if button["glow_color"]:
            _draw_button_glow(surface, button["rect"], button["glow_color"])

        pygame.draw.rect(surface, button["bg_color"], button["rect"], border_radius=config.BUTTON_BORDER_RADIUS)

        if button["icon"] == "check":
            _draw_check_icon(surface, button["rect"], button["text_color"])
        elif button["icon"] == "arrow_left":
            _draw_arrow_left_icon(surface, button["rect"], button["text_color"])
        elif button["icon"] == "gear":
            _draw_gear_icon(surface, button["rect"], button["text_color"])
        elif button["label"]:
            label = font.render(button["label"], True, button["text_color"])
            surface.blit(label, label.get_rect(center=button["rect"].center))


def build_settings_panel(settings, pending, font, window_width, window_height):
    """Раскладка модальной панели настроек: размер поля/режим/сложность/применить
    (превью, как в build_button_layout) + переключатели, применяющиеся сразу."""
    panel_width = min(config.SETTINGS_PANEL_WIDTH, window_width - 40)
    controls = []

    padding = config.SETTINGS_PANEL_PADDING
    row_height = config.SETTINGS_PANEL_ROW_HEIGHT
    row_count = 3  # размер поля + режим + закрыть, дальше по условиям
    if pending.game_mode == MODE_PVE:
        row_count += 1  # сложность
    if not pending.matches_gameplay(settings):
        row_count += 1  # применить
    row_count += 1  # переключатель "разрешить отмену хода" — виден всегда
    if pending.game_mode == MODE_PVE:
        row_count += 1  # "подсвечивать угрозы" — только когда есть бот

    panel_height = config.SETTINGS_PANEL_TITLE_HEIGHT + row_count * row_height + padding
    panel_rect = pygame.Rect(0, 0, panel_width, panel_height)
    panel_rect.center = (window_width // 2, window_height // 2)

    row_y = panel_rect.top + config.SETTINGS_PANEL_TITLE_HEIGHT
    content_width = panel_rect.width - padding * 2

    def add_row_button(control_id, label, bg_color, text_color):
        nonlocal row_y
        rect = pygame.Rect(panel_rect.left + padding, row_y, content_width, config.BUTTON_HEIGHT)
        controls.append(
            {
                "kind": "button",
                "id": control_id,
                "rect": rect,
                "label": label,
                "bg_color": bg_color,
                "text_color": text_color,
            }
        )
        row_y += row_height

    def add_checkbox(control_id, label, checked):
        nonlocal row_y
        rect = pygame.Rect(panel_rect.left + padding, row_y, content_width, config.CHECKBOX_SIZE)
        controls.append({"kind": "checkbox", "id": control_id, "rect": rect, "label": label, "checked": checked})
        row_y += row_height

    board_size_label = f"Размер поля: {pending.board_size}×{pending.board_size}"
    add_row_button("panel_board_size", board_size_label, config.COLOR_BUTTON_NEUTRAL, config.COLOR_BUTTON_NEUTRAL_TEXT)

    mode_label = "Режим: Игрок vs Бот" if pending.game_mode == MODE_PVE else "Режим: Игрок vs Игрок"
    add_row_button("panel_mode", mode_label, config.COLOR_BUTTON_NEUTRAL, config.COLOR_BUTTON_NEUTRAL_TEXT)

    if pending.game_mode == MODE_PVE:
        difficulty_label = f"Сложность: {DIFFICULTY_LABELS[pending.difficulty]}"
        add_row_button("panel_difficulty", difficulty_label, config.COLOR_BUTTON_NEUTRAL, config.COLOR_BUTTON_NEUTRAL_TEXT)

    if not pending.matches_gameplay(settings):
        add_row_button("panel_apply", "Применить", config.COLOR_BUTTON_APPLY, config.COLOR_BUTTON_APPLY_TEXT)

    add_checkbox("panel_allow_undo", "Разрешить отмену хода", settings.allow_undo)

    if pending.game_mode == MODE_PVE:
        add_checkbox("panel_highlight_threats", "Подсвечивать угрозы бота", settings.highlight_threats)

    add_row_button("panel_close", "Закрыть", config.COLOR_BUTTON_NEUTRAL, config.COLOR_BUTTON_NEUTRAL_TEXT)

    return panel_rect, controls


def draw_settings_panel(surface, font, panel_rect, controls):
    overlay = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    overlay.fill(config.COLOR_SETTINGS_OVERLAY)
    surface.blit(overlay, (0, 0))

    pygame.draw.rect(surface, config.COLOR_SETTINGS_PANEL_BG, panel_rect, border_radius=10)
    pygame.draw.rect(surface, config.COLOR_SETTINGS_PANEL_BORDER, panel_rect, 2, border_radius=10)

    title = font.render(config.SETTINGS_PANEL_TITLE, True, config.COLOR_TEXT)
    surface.blit(title, (panel_rect.centerx - title.get_width() // 2, panel_rect.top + 16))

    for control in controls:
        if control["kind"] == "button":
            pygame.draw.rect(surface, control["bg_color"], control["rect"], border_radius=config.BUTTON_BORDER_RADIUS)
            label = font.render(control["label"], True, control["text_color"])
            surface.blit(label, label.get_rect(center=control["rect"].center))
        else:
            box_rect = pygame.Rect(control["rect"].left, control["rect"].top, config.CHECKBOX_SIZE, config.CHECKBOX_SIZE)
            pygame.draw.rect(surface, config.COLOR_BUTTON_NEUTRAL, box_rect, border_radius=4)
            pygame.draw.rect(surface, config.COLOR_SETTINGS_PANEL_BORDER, box_rect, 2, border_radius=4)
            if control["checked"]:
                _draw_check_icon(surface, box_rect, config.COLOR_UNDO_ICON)

            label = font.render(control["label"], True, config.COLOR_TEXT)
            label_y = box_rect.centery - label.get_height() // 2
            surface.blit(label, (box_rect.right + config.CHECKBOX_LABEL_GAP, label_y))
