"""Точка входа для мобильной (веб/pygbag) сборки.

Отличия от десктопной A:\\5 в ряд\\main.py — только то, что реально требует браузер:
1. Асинхронный игровой цикл с `await asyncio.sleep(0)` — обязательное требование
   pygbag/emscripten, иначе браузерная вкладка не сможет отрисовывать кадры между
   итерациями цикла.
2. Шрифт — не системный (в браузере нет доступа к шрифтам ОС вроде Consolas),
   а встроенный в сам pygame (`pygame.font.Font(None, size)`), который гарантированно
   доступен и в WASM-сборке, и на десктопе.

Вся игровая логика и отрисовка (board/rules/game_state/settings/bot/renderer/ui) —
буквально те же файлы, что в десктопной версии, без единого изменения.
"""

import asyncio
from dataclasses import replace

import pygame

import config
from board import PLAYER_O
from settings import Settings, MODE_PVE
from game_state import GameState, STATUS_PLAYING
from input_handler import get_clicked_cell, get_clicked_button
from renderer import draw_board, board_pixel_size
from ui import (
    build_button_layout,
    draw_buttons,
    draw_hud_background,
    draw_status_text,
    build_settings_panel,
    draw_settings_panel,
)
import bot


def handle_button(button_id, settings, pending, game_state):
    """Возвращает (settings, pending, game_state, panel_open, should_quit)."""
    if button_id == "restart":
        return settings, pending, GameState(settings.board_size), False, False
    if button_id == "settings":
        return settings, pending, game_state, True, False
    if button_id == "surrender":
        game_state.surrender()
        return settings, pending, game_state, False, False
    if button_id == "undo":
        game_state.undo_last_move()
        if settings.game_mode == MODE_PVE:
            game_state.undo_last_move()  # снимаем и ответ бота, и свой ход
        return settings, pending, game_state, False, False
    if button_id == "exit":
        return settings, pending, game_state, False, True
    return settings, pending, game_state, False, False


def handle_panel_control(control_id, settings, pending, game_state, panel_open):
    """Возвращает (settings, pending, game_state, panel_open)."""
    if control_id == "panel_board_size":
        pending.cycle_board_size()
    elif control_id == "panel_mode":
        pending.toggle_mode()
    elif control_id == "panel_difficulty":
        pending.cycle_difficulty()
    elif control_id == "panel_apply":
        settings = replace(pending)
        game_state = GameState(settings.board_size)
        panel_open = False
    elif control_id == "panel_allow_undo":
        settings.allow_undo = not settings.allow_undo
        pending.allow_undo = settings.allow_undo
    elif control_id == "panel_highlight_threats":
        settings.highlight_threats = not settings.highlight_threats
        pending.highlight_threats = settings.highlight_threats
    elif control_id == "panel_close":
        panel_open = False
    return settings, pending, game_state, panel_open


async def main():
    settings = Settings()
    settings.validate()
    pending = replace(settings)

    pygame.init()
    pygame.display.set_caption("5 в ряд")

    width = board_pixel_size(settings.board_size)
    height = config.HUD_HEIGHT + board_pixel_size(settings.board_size)
    screen = pygame.display.set_mode((width, height))

    font = pygame.font.Font(None, config.FONT_SIZE_HUD)
    font.set_bold(True)
    button_font = pygame.font.Font(None, config.FONT_SIZE_BUTTON)
    button_font.set_bold(True)
    panel_font = button_font

    clock = pygame.time.Clock()

    game_state = GameState(settings.board_size)
    panel_open = False

    running = True
    while running:
        buttons = build_button_layout(settings, pending, game_state, button_font)
        panel_rect, panel_controls = (
            build_settings_panel(settings, pending, panel_font, width, height) if panel_open else (None, [])
        )

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                continue

            if panel_open:
                control_id = get_clicked_button(event, panel_controls)
                if control_id:
                    settings, pending, game_state, panel_open = handle_panel_control(
                        control_id, settings, pending, game_state, panel_open
                    )
                    if control_id == "panel_apply":
                        width = board_pixel_size(settings.board_size)
                        height = config.HUD_HEIGHT + board_pixel_size(settings.board_size)
                        screen = pygame.display.set_mode((width, height))
                continue

            button_id = get_clicked_button(event, buttons)
            if button_id:
                settings, pending, game_state, panel_open, should_quit = handle_button(
                    button_id, settings, pending, game_state
                )
                if should_quit:
                    running = False
                continue

            if game_state.status == STATUS_PLAYING:
                cell = get_clicked_cell(event, settings.board_size)
                if cell:
                    row, col = cell
                    moved = game_state.make_move(row, col)

                    if moved and not pending.matches_gameplay(settings):
                        pending = replace(settings)

                    if (
                        moved
                        and settings.game_mode == MODE_PVE
                        and game_state.status == STATUS_PLAYING
                    ):
                        bot_move = bot.choose_move(
                            game_state.board, game_state.current_player, settings.difficulty
                        )
                        if bot_move:
                            game_state.make_move(*bot_move)

        threat_cells = None
        if settings.game_mode == MODE_PVE and settings.highlight_threats:
            threat_cells = bot.find_threat_cells(game_state.board, PLAYER_O)

        screen.fill(config.COLOR_BACKGROUND)
        draw_hud_background(screen, width)
        draw_buttons(screen, button_font, buttons)
        draw_status_text(screen, font, game_state)
        draw_board(screen, game_state, threat_cells)

        if panel_open:
            panel_rect, panel_controls = build_settings_panel(settings, pending, panel_font, width, height)
            draw_settings_panel(screen, panel_font, panel_rect, panel_controls)

        pygame.display.flip()
        clock.tick(config.FPS)
        await asyncio.sleep(0)  # отдаём управление браузеру между кадрами — без этого вкладка "зависнет"

    pygame.quit()


if __name__ == "__main__":
    asyncio.run(main())
