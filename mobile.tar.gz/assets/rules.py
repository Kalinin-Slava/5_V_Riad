"""Проверка победы (линии длины 5), поиск координат выигрышной линии."""

from config import WIN_LENGTH
from board import EMPTY

DIRECTIONS = [(0, 1), (1, 0), (1, 1), (1, -1)]


def check_win(board, row, col):
    """Проверяет, образует ли фигура в (row, col) линию нужной длины.

    Возвращает список координат линии (от начала до конца) или None.
    """
    player = board.get(row, col)
    if player == EMPTY:
        return None

    for d_row, d_col in DIRECTIONS:
        line = [(row, col)]

        r, c = row + d_row, col + d_col
        while board.in_bounds(r, c) and board.get(r, c) == player:
            line.append((r, c))
            r += d_row
            c += d_col

        r, c = row - d_row, col - d_col
        while board.in_bounds(r, c) and board.get(r, c) == player:
            line.insert(0, (r, c))
            r -= d_row
            c -= d_col

        if len(line) >= WIN_LENGTH:
            return line

    return None


def is_draw(board):
    return board.is_full()
