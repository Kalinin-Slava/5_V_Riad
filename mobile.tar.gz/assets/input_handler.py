"""Преобразование событий мыши/клавиатуры в координаты клетки / клики по UI."""

import pygame

from renderer import pixel_to_cell


def get_clicked_cell(event, board_size):
    if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
        return None
    x, y = event.pos
    return pixel_to_cell(x, y, board_size)


def get_clicked_button(event, buttons):
    if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
        return None
    for button in buttons:
        if button["rect"].collidepoint(event.pos):
            return button["id"]
    return None
