"""Модель поля: хранение состояния клеток, установка/чтение фигур, проверка границ."""

EMPTY = 0
PLAYER_X = 1
PLAYER_O = 2


class Board:
    def __init__(self, size):
        self.size = size
        self._cells = [[EMPTY] * size for _ in range(size)]
        self._occupied = set()

    def in_bounds(self, row, col):
        return 0 <= row < self.size and 0 <= col < self.size

    def get(self, row, col):
        return self._cells[row][col]

    def set(self, row, col, player):
        if not self.in_bounds(row, col):
            raise ValueError(f"Клетка ({row}, {col}) вне поля")
        if self._cells[row][col] != EMPTY:
            raise ValueError(f"Клетка ({row}, {col}) уже занята")
        self._cells[row][col] = player
        self._occupied.add((row, col))

    def clear(self, row, col):
        self._cells[row][col] = EMPTY
        self._occupied.discard((row, col))

    def is_empty(self, row, col):
        return self.in_bounds(row, col) and self._cells[row][col] == EMPTY

    def is_full(self):
        return len(self._occupied) == self.size * self.size

    def occupied_cells(self):
        """Множество (row, col) уже занятых клеток. Только для чтения — не изменять."""
        return self._occupied
