"""ИИ-бот: генерация кандидатов, эвристика, минимакс с альфа-бета отсечением.

Уровни сложности:
- Новичок: полностью случайный ход (без анализа угроз).
- Лёгкий: блокирует немедленную победу соперника и открытую тройку/четвёрку
  по эвристике, иначе — ход рядом со своими фигурами с элементом случайности.
- Средний: минимакс глубиной 2 (свой ход + ответ соперника), гарантированно
  блокирует прямую угрозу победы соперника следующим ходом.
- Сложный: минимакс с альфа-бета и итеративным углублением (до 4 ходов),
  ограниченным списком кандидатов и тайм-бюджетом ~3 секунды.
"""

import random
import time

from board import EMPTY, PLAYER_X, PLAYER_O
from config import WIN_LENGTH
from rules import check_win
from settings import DIFFICULTY_NOVICE, DIFFICULTY_EASY, DIFFICULTY_MEDIUM, DIFFICULTY_HARD

CANDIDATE_RADIUS = 2
OPPONENT = {PLAYER_X: PLAYER_O, PLAYER_O: PLAYER_X}

# Очки за линию длины `count` (2..5) с числом открытых концов `open_ends` (0, 1, 2).
LINE_SCORE = {
    (5, 0): 100_000_000,
    (5, 1): 100_000_000,
    (5, 2): 100_000_000,
    (4, 2): 1_000_000,
    (4, 1): 10_000,
    (3, 2): 5_000,
    (3, 1): 500,
    (2, 2): 200,
    (2, 1): 50,
}
BLOCK_THRESHOLD = LINE_SCORE[(3, 2)]  # с этого порога считаем угрозу соперника значимой

DIRECTIONS = [(0, 1), (1, 0), (1, 1), (1, -1)]

DIFFICULTY_PARAMS = {
    DIFFICULTY_MEDIUM: {"depth": 2, "max_candidates": 12},
    DIFFICULTY_HARD: {"depth": 4, "max_candidates": 10},
}
HARD_TIME_BUDGET = 2.7  # секунд, с запасом под лимит 3с из ТЗ
MEDIUM_TIME_BUDGET = 5.0


def opponent(player):
    return OPPONENT[player]


def _candidate_moves(board):
    occupied = board.occupied_cells()
    if not occupied:
        center = board.size // 2
        return [(center, center)]

    candidates = set()
    for row, col in occupied:
        for d_row in range(-CANDIDATE_RADIUS, CANDIDATE_RADIUS + 1):
            for d_col in range(-CANDIDATE_RADIUS, CANDIDATE_RADIUS + 1):
                r, c = row + d_row, col + d_col
                if board.in_bounds(r, c) and board.get(r, c) == EMPTY:
                    candidates.add((r, c))
    return list(candidates)


def _open_run_length(board, row, col, d_row, d_col):
    """Сколько подряд пустых клеток начиная с (row, col) в направлении (d_row, d_col)."""
    count = 0
    r, c = row, col
    while board.in_bounds(r, c) and board.get(r, c) == EMPTY:
        count += 1
        r += d_row
        c += d_col
    return count


def _line_cells_through(board, row, col, d_row, d_col, player):
    """Клетки сплошной линии `player`, проходящей ЧЕРЕЗ (row, col) (считает в обе стороны),
    и признак того, что эту линию ещё реально можно достроить до WIN_LENGTH — то есть
    суммы длины линии и свободного места по обе стороны хватает, а не просто "конец не занят"."""
    cells = [(row, col)]

    r, c = row + d_row, col + d_col
    while board.in_bounds(r, c) and board.get(r, c) == player:
        cells.append((r, c))
        r += d_row
        c += d_col
    end_space = _open_run_length(board, r, c, d_row, d_col)

    r, c = row - d_row, col - d_col
    while board.in_bounds(r, c) and board.get(r, c) == player:
        cells.append((r, c))
        r -= d_row
        c -= d_col
    start_space = _open_run_length(board, r, c, -d_row, -d_col)

    can_reach_win_length = len(cells) + start_space + end_space >= WIN_LENGTH
    return cells, can_reach_win_length


def find_threat_cells(board, player):
    """Все клетки `player`, входящие в линию длины >= 3, которую ещё реально можно
    дотянуть до WIN_LENGTH — значимая, физически достижимая угроза победы."""
    threat_cells = set()
    for row, col in board.occupied_cells():
        if board.get(row, col) != player:
            continue
        for d_row, d_col in DIRECTIONS:
            cells, can_reach_win_length = _line_cells_through(board, row, col, d_row, d_col, player)
            if len(cells) >= 3 and can_reach_win_length:
                threat_cells.update(cells)
    return threat_cells


def _line_run(board, row, col, d_row, d_col, player):
    """Длина и число открытых концов сплошной линии `player`, начинающейся в (row, col).
    Возвращает None, если линия уже была посчитана с более раннего старта."""
    prev_r, prev_c = row - d_row, col - d_col
    if board.in_bounds(prev_r, prev_c) and board.get(prev_r, prev_c) == player:
        return None

    length = 0
    r, c = row, col
    while board.in_bounds(r, c) and board.get(r, c) == player:
        length += 1
        r += d_row
        c += d_col

    start_open = board.in_bounds(prev_r, prev_c) and board.get(prev_r, prev_c) == EMPTY
    end_open = board.in_bounds(r, c) and board.get(r, c) == EMPTY
    return length, int(start_open) + int(end_open)


def evaluate_board(board, player):
    """Эвристическая оценка позиции с точки зрения `player`: сумма очков за свои линии
    минус очки за линии соперника, по открытым/закрытым линиям длины 2-5."""
    score = 0
    for row, col in board.occupied_cells():
        cell = board.get(row, col)
        for d_row, d_col in DIRECTIONS:
            result = _line_run(board, row, col, d_row, d_col, cell)
            if result is None:
                continue
            length, open_ends = result
            pattern_score = LINE_SCORE.get((min(length, 5), open_ends), 0)
            score += pattern_score if cell == player else -pattern_score
    return score


def _find_immediate_win(board, target_player, moves):
    for row, col in moves:
        board.set(row, col, target_player)
        won = check_win(board, row, col) is not None
        board.clear(row, col)
        if won:
            return (row, col)
    return None


def _find_best_blocking_move(board, player, opp, moves):
    current_threat = evaluate_board(board, opp)
    if current_threat < BLOCK_THRESHOLD:
        return None

    best_move = None
    best_after = current_threat
    for row, col in moves:
        board.set(row, col, player)
        after = evaluate_board(board, opp)
        board.clear(row, col)
        if after < best_after:
            best_after = after
            best_move = (row, col)
    return best_move


def _choose_novice_move(board):
    empty_cells = [
        (r, c) for r in range(board.size) for c in range(board.size) if board.get(r, c) == EMPTY
    ]
    return random.choice(empty_cells) if empty_cells else None


def _choose_easy_move(board, player, opp, moves):
    threat_move = _find_best_blocking_move(board, player, opp, moves)
    if threat_move:
        return threat_move

    scored = []
    for row, col in moves:
        board.set(row, col, player)
        score = evaluate_board(board, player)
        board.clear(row, col)
        scored.append((score, row, col))

    scored.sort(reverse=True)
    best_score = scored[0][0]
    best_moves = [(r, c) for score, r, c in scored if score == best_score]
    return random.choice(best_moves)


def _order_candidates(board, player, candidates):
    scored = []
    for row, col in candidates:
        board.set(row, col, player)
        score = evaluate_board(board, player)
        board.clear(row, col)
        scored.append((score, row, col))
    scored.sort(reverse=True)
    return [(row, col) for _, row, col in scored]


def _minimax(board, depth, player, root_player, alpha, beta, deadline, candidate_pool):
    available = [(r, c) for r, c in candidate_pool if board.get(r, c) == EMPTY]

    if depth == 0 or not available or time.monotonic() > deadline:
        return evaluate_board(board, root_player), None

    maximizing = player == root_player
    best_score = float("-inf") if maximizing else float("inf")
    best_move = available[0]

    for row, col in available:
        board.set(row, col, player)
        if check_win(board, row, col):
            score = 10**8 if player == root_player else -(10**8)
        else:
            score, _ = _minimax(
                board, depth - 1, opponent(player), root_player, alpha, beta, deadline, candidate_pool
            )
        board.clear(row, col)

        if maximizing:
            if score > best_score:
                best_score, best_move = score, (row, col)
            alpha = max(alpha, best_score)
        else:
            if score < best_score:
                best_score, best_move = score, (row, col)
            beta = min(beta, best_score)

        if alpha >= beta or time.monotonic() > deadline:
            break

    return best_score, best_move


def _search_best_move(board, player, candidate_pool, depth, deadline):
    best_score = float("-inf")
    best_move = candidate_pool[0]

    for row, col in candidate_pool:
        board.set(row, col, player)
        if check_win(board, row, col):
            score = 10**8
        else:
            score, _ = _minimax(
                board, depth - 1, opponent(player), player,
                float("-inf"), float("inf"), deadline, candidate_pool,
            )
        board.clear(row, col)

        if score > best_score:
            best_score, best_move = score, (row, col)

        if time.monotonic() > deadline:
            break

    return best_move


def _choose_medium_move(board, player, moves):
    params = DIFFICULTY_PARAMS[DIFFICULTY_MEDIUM]
    pool = _order_candidates(board, player, moves)[: params["max_candidates"]]
    deadline = time.monotonic() + MEDIUM_TIME_BUDGET
    return _search_best_move(board, player, pool, params["depth"], deadline)


def _choose_hard_move(board, player, moves):
    params = DIFFICULTY_PARAMS[DIFFICULTY_HARD]
    pool = _order_candidates(board, player, moves)[: params["max_candidates"]]
    deadline = time.monotonic() + HARD_TIME_BUDGET

    best_move = pool[0]
    depth = 1
    while depth <= params["depth"] and time.monotonic() < deadline:
        move = _search_best_move(board, player, pool, depth, deadline)
        if move is not None:
            best_move = move
        depth += 1

    return best_move


def choose_move(board, player, difficulty=DIFFICULTY_MEDIUM):
    moves = _candidate_moves(board)
    if not moves:
        return None

    if difficulty == DIFFICULTY_NOVICE:
        return _choose_novice_move(board)

    opp = opponent(player)

    own_win = _find_immediate_win(board, player, moves)
    if own_win:
        return own_win

    if difficulty == DIFFICULTY_EASY:
        return _choose_easy_move(board, player, opp, moves)

    # Средний и Сложный: гарантированно блокируем прямую угрозу победы соперника
    opp_win = _find_immediate_win(board, opp, moves)
    if opp_win:
        return opp_win

    if difficulty == DIFFICULTY_MEDIUM:
        return _choose_medium_move(board, player, moves)

    return _choose_hard_move(board, player, moves)
