"""Отрисовка игрового поля: сетка, фигуры, подсветки, линия победы.

Кнопки, HUD и панель настроек — в ui.py. Этот модуль не содержит игровой логики,
только чтение состояния (`game_state`) и рисование.
"""

import math

import pygame

import config
from board import PLAYER_X, PLAYER_O
from game_state import STATUS_PLAYING, STATUS_WIN


def board_pixel_size(board_size):
    return config.BOARD_MARGIN * 2 + config.CELL_SIZE * board_size


def _grid_point(row, col):
    """Координаты пересечения линий сетки (углы клеток)."""
    x = config.BOARD_MARGIN + col * config.CELL_SIZE
    y = config.HUD_HEIGHT + config.BOARD_MARGIN + row * config.CELL_SIZE
    return x, y


def cell_center(row, col):
    """Координаты центра клетки (row, col) — сюда рисуется фигура."""
    x, y = _grid_point(row, col)
    return x + config.CELL_SIZE // 2, y + config.CELL_SIZE // 2


def pixel_to_cell(x, y, board_size):
    col = (x - config.BOARD_MARGIN) // config.CELL_SIZE
    row = (y - config.HUD_HEIGHT - config.BOARD_MARGIN) // config.CELL_SIZE
    if 0 <= row < board_size and 0 <= col < board_size:
        return int(row), int(col)
    return None


def draw_grid(surface, board_size):
    for i in range(board_size + 1):
        start = _grid_point(i, 0)
        end = _grid_point(i, board_size)
        pygame.draw.line(surface, config.COLOR_GRID_LINE, start, end, 1)

        start = _grid_point(0, i)
        end = _grid_point(board_size, i)
        pygame.draw.line(surface, config.COLOR_GRID_LINE, start, end, 1)


def _draw_cross(surface, x, y, radius, color, width):
    pygame.draw.line(surface, color, (x - radius, y - radius), (x + radius, y + radius), width)
    pygame.draw.line(surface, color, (x - radius, y + radius), (x + radius, y - radius), width)


def _draw_circle(surface, x, y, radius, color, width):
    pygame.draw.circle(surface, color, (x, y), radius, width)


_mark_surface_cache = {}


def _build_neon_surface(shape_draw_fn, radius, color):
    size = config.CELL_SIZE
    center = size // 2

    glow_surface = pygame.Surface((size, size), pygame.SRCALPHA)
    for extra, alpha, width in config.NEON_GLOW_LAYERS:
        layer_color = (*color, alpha)
        shape_draw_fn(glow_surface, center, center, radius + extra, layer_color, width)
    shape_draw_fn(glow_surface, center, center, radius, (*color, 255), config.NEON_CORE_WIDTH)
    return glow_surface


def _get_neon_surface(shape_draw_fn, radius, color):
    """Готовая поверхность фигуры со свечением, посчитанная один раз и переиспользуемая
    при каждой отрисовке — иначе она пересоздавалась бы на каждую клетку каждый кадр."""
    key = (shape_draw_fn, radius, color)
    cached = _mark_surface_cache.get(key)
    if cached is None:
        cached = _build_neon_surface(shape_draw_fn, radius, color)
        _mark_surface_cache[key] = cached
    return cached


def _draw_neon_shape(surface, shape_draw_fn, row, col, radius, color):
    """Рисует символ с неоновым свечением на поверхности размером ровно с клетку —
    свечение физически не может выйти за границы своей клетки."""
    glow_surface = _get_neon_surface(shape_draw_fn, radius, color)
    top_left_x, top_left_y = _grid_point(row, col)
    surface.blit(glow_surface, (top_left_x, top_left_y))


def _darken(color, factor):
    return tuple(int(c * factor) for c in color)


def _draw_mark_tile(surface, row, col, color):
    x, y = _grid_point(row, col)
    rect = pygame.Rect(x, y, config.CELL_SIZE, config.CELL_SIZE)
    pygame.draw.rect(surface, _darken(color, config.MARK_TILE_DARKEN_FACTOR), rect)


def draw_mark(surface, row, col, player):
    radius = config.CELL_SIZE // config.NEON_CORE_RADIUS_DIVISOR

    if player == PLAYER_X:
        _draw_mark_tile(surface, row, col, config.COLOR_PLAYER_X)
        _draw_neon_shape(surface, _draw_cross, row, col, radius, config.COLOR_PLAYER_X)
    elif player == PLAYER_O:
        _draw_mark_tile(surface, row, col, config.COLOR_PLAYER_O)
        _draw_neon_shape(surface, _draw_circle, row, col, radius, config.COLOR_PLAYER_O)


def draw_last_move_highlight(surface, row, col, color):
    x, y = _grid_point(row, col)
    rect = pygame.Rect(x, y, config.CELL_SIZE, config.CELL_SIZE)
    pygame.draw.rect(surface, color, rect, 2)


def draw_danger_highlight(surface, row, col):
    """Предупреждающая рамка вокруг клетки с угрозой."""
    x, y = _grid_point(row, col)
    pad = config.DANGER_HIGHLIGHT_PADDING
    rect = pygame.Rect(x - pad, y - pad, config.CELL_SIZE + pad * 2, config.CELL_SIZE + pad * 2)
    pygame.draw.rect(surface, config.COLOR_DANGER_HIGHLIGHT, rect, config.DANGER_HIGHLIGHT_WIDTH, border_radius=4)


def draw_winning_line(surface, line, color):
    if not line:
        return
    start = cell_center(*line[0])
    end = cell_center(*line[-1])

    dx, dy = end[0] - start[0], end[1] - start[1]
    length = math.hypot(dx, dy)
    if length == 0:
        return
    ux, uy = dx / length, dy / length
    extra = config.WIN_LINE_EXTRA_LENGTH

    start = (start[0] - ux * extra, start[1] - uy * extra)
    end = (end[0] + ux * extra, end[1] + uy * extra)
    pygame.draw.line(surface, color, start, end, config.WIN_LINE_WIDTH)


def draw_board(surface, game_state, threat_cells=None):
    """Рисует сетку, фигуры и все подсветки поля (угрозы, последний ход, линия победы)."""
    draw_grid(surface, game_state.board.size)

    for row, col in game_state.board.occupied_cells():
        draw_mark(surface, row, col, game_state.board.get(row, col))

    if threat_cells:
        for row, col in threat_cells:
            draw_danger_highlight(surface, row, col)

    last = game_state.last_move()
    if last and game_state.status == STATUS_PLAYING:
        row, col, player = last
        color = config.COLOR_PLAYER_X if player == PLAYER_X else config.COLOR_PLAYER_O
        draw_last_move_highlight(surface, row, col, color)

    if game_state.status == STATUS_WIN:
        winner_color = config.COLOR_PLAYER_X if game_state.winner == PLAYER_X else config.COLOR_PLAYER_O
        line_color = _darken(winner_color, config.WIN_LINE_DARKEN_FACTOR)
        draw_winning_line(surface, game_state.winning_line, line_color)
