"""Состояние партии: чей ход, история ходов, статус (идёт игра/победа/ничья)."""

from board import Board, PLAYER_X, PLAYER_O
from rules import check_win, is_draw

STATUS_PLAYING = "playing"
STATUS_WIN = "win"
STATUS_DRAW = "draw"


class GameState:
    def __init__(self, board_size):
        self.board = Board(board_size)
        self.current_player = PLAYER_X
        self.history = []
        self.status = STATUS_PLAYING
        self.winner = None
        self.winning_line = None

    def make_move(self, row, col):
        if self.status != STATUS_PLAYING:
            return False
        if not self.board.is_empty(row, col):
            return False

        self.board.set(row, col, self.current_player)
        self.history.append((row, col, self.current_player))

        winning_line = check_win(self.board, row, col)
        if winning_line:
            self.status = STATUS_WIN
            self.winner = self.current_player
            self.winning_line = winning_line
        elif is_draw(self.board):
            self.status = STATUS_DRAW
        else:
            self.current_player = PLAYER_O if self.current_player == PLAYER_X else PLAYER_X

        return True

    def last_move(self):
        return self.history[-1] if self.history else None

    def surrender(self):
        if self.status != STATUS_PLAYING:
            return
        self.status = STATUS_WIN
        self.winner = PLAYER_O if self.current_player == PLAYER_X else PLAYER_X
        self.winning_line = None

    def undo_last_move(self):
        if not self.history:
            return False
        row, col, player = self.history.pop()
        self.board.clear(row, col)
        self.current_player = player
        self.status = STATUS_PLAYING
        self.winner = None
        self.winning_line = None
        return True
