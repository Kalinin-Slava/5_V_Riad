"""Хранение и валидация настроек, выбранных в меню (размер поля, режим, сложность)."""

from dataclasses import dataclass

from config import DEFAULT_BOARD_SIZE, MIN_BOARD_SIZE, MAX_BOARD_SIZE

MODE_PVP = "pvp"
MODE_PVE = "pve"

DIFFICULTY_NOVICE = "novice"  # рандомные ходы, слабее "Лёгкого"
DIFFICULTY_EASY = "easy"
DIFFICULTY_MEDIUM = "medium"
DIFFICULTY_HARD = "hard"
DIFFICULTY_ORDER = [DIFFICULTY_NOVICE, DIFFICULTY_EASY, DIFFICULTY_MEDIUM, DIFFICULTY_HARD]

BOARD_SIZE_OPTIONS = [9, 13, 15, 19]


@dataclass
class Settings:
    board_size: int = DEFAULT_BOARD_SIZE
    game_mode: str = MODE_PVP
    difficulty: str = DIFFICULTY_MEDIUM
    player_starts: bool = True
    allow_undo: bool = True
    highlight_threats: bool = True

    def validate(self):
        if not (MIN_BOARD_SIZE <= self.board_size <= MAX_BOARD_SIZE):
            raise ValueError(
                f"Размер поля должен быть от {MIN_BOARD_SIZE} до {MAX_BOARD_SIZE}"
            )
        if self.game_mode not in (MODE_PVP, MODE_PVE):
            raise ValueError(f"Неизвестный режим игры: {self.game_mode}")
        if self.difficulty not in DIFFICULTY_ORDER:
            raise ValueError(f"Неизвестная сложность: {self.difficulty}")

    def toggle_mode(self):
        self.game_mode = MODE_PVP if self.game_mode == MODE_PVE else MODE_PVE

    def cycle_difficulty(self):
        next_index = (DIFFICULTY_ORDER.index(self.difficulty) + 1) % len(DIFFICULTY_ORDER)
        self.difficulty = DIFFICULTY_ORDER[next_index]

    def cycle_board_size(self):
        if self.board_size in BOARD_SIZE_OPTIONS:
            next_index = (BOARD_SIZE_OPTIONS.index(self.board_size) + 1) % len(BOARD_SIZE_OPTIONS)
        else:
            next_index = 0
        self.board_size = BOARD_SIZE_OPTIONS[next_index]

    def matches_gameplay(self, other):
        """Совпадают ли размер поля/режим/сложность (без учёта allow_undo/highlight_threats) —
        используется, чтобы понять, есть ли неподтверждённое превью настроек."""
        return (
            self.board_size == other.board_size
            and self.game_mode == other.game_mode
            and self.difficulty == other.difficulty
        )
