"""Константы, настройки по умолчанию, цветовая схема, размеры окна."""

CELL_SIZE = 40
BOARD_MARGIN = 40

BUTTON_ROW_HEIGHT = 44
STATUS_ROW_HEIGHT = 40
BUTTON_HEIGHT = 32

HUD_HEIGHT = BUTTON_ROW_HEIGHT + STATUS_ROW_HEIGHT

DEFAULT_BOARD_SIZE = 15
MIN_BOARD_SIZE = 9
MAX_BOARD_SIZE = 25
WIN_LENGTH = 5

FPS = 60

COLOR_BACKGROUND = (0, 0, 0)
COLOR_GRID_LINE = (60, 60, 60)
COLOR_TEXT = (230, 230, 230)

COLOR_PLAYER_X = (60, 220, 255)   # неоновый голубой
COLOR_PLAYER_O = (255, 45, 170)   # неоновый розовый/малиновый

COLOR_HUD_BACKGROUND = (0, 0, 0)

WIN_LINE_WIDTH = 5
WIN_LINE_EXTRA_LENGTH = CELL_SIZE  # на сколько пикселей линия выходит за крайние фигуры с каждой стороны
WIN_LINE_DARKEN_FACTOR = 0.7  # линия чуть темнее цвета фигур победителя

NEON_CORE_RADIUS_DIVISOR = 4  # радиус ядра символа = CELL_SIZE // это число

# Неоновое свечение: слои (доп. радиус в пикселях сверх ядра, альфа, толщина линии),
# от самого широкого/тусклого к самому узкому/яркому. Слои рисуются на поверхности
# размером ровно с клетку, поэтому свечение физически не может выйти за её пределы.
NEON_GLOW_LAYERS = [
    (6, 40, 6),
    (4, 80, 5),
    (2, 140, 4),
]
NEON_CORE_WIDTH = 3

MARK_TILE_DARKEN_FACTOR = 0.16  # подложка под фигурой = её цвет, затемнённый до этой доли

FONT_NAME = "consolas,couriernew,monospace"  # моноширинный "техно" шрифт
FONT_SIZE_HUD = 30
FONT_SIZE_BUTTON = 18
COLOR_HUD_TEXT_SHADOW = (110, 110, 110)
HUD_TEXT_SHADOW_OFFSET = (3, 3)

# Кнопки верхней панели
BUTTON_TOP_Y = (BUTTON_ROW_HEIGHT - BUTTON_HEIGHT) // 2
BUTTON_ROW_LEFT_MARGIN = 10  # "Рестарт"/"Настройки" прижаты к левому краю окна, а не к отступу сетки
BUTTON_PADDING_X = 14
BUTTON_GAP = 8
BUTTON_BORDER_RADIUS = 6

COLOR_BUTTON_NEUTRAL = (40, 40, 40)
COLOR_BUTTON_NEUTRAL_TEXT = COLOR_TEXT

COLOR_UNDO_ICON = (235, 60, 60)  # красная стрелка "отменить ход" (только в игре с ботом)

COLOR_SURRENDER_TEXT = (15, 15, 15)  # тёмный текст на ярком неоновом фоне кнопки

COLOR_BUTTON_APPLY = (255, 195, 40)  # заметный акцент — есть несохранённое изменение настроек
COLOR_BUTTON_APPLY_TEXT = (20, 20, 20)

COLOR_DANGER_HIGHLIGHT = (255, 100, 0)  # предупреждающая рамка вокруг клеток с угрозой
DANGER_HIGHLIGHT_WIDTH = 2
DANGER_HIGHLIGHT_PADDING = 1  # на сколько рамка шире клетки

COLOR_BUTTON_EXIT = (30, 180, 90)
COLOR_BUTTON_EXIT_TEXT = (255, 255, 255)
COLOR_BUTTON_EXIT_GLOW = (120, 255, 170)
BUTTON_EXIT_GLOW_LAYERS = [
    (6, 35),
    (3, 70),
]

# Модальная панель настроек (шестерёнка в верхней панели)
COLOR_SETTINGS_PANEL_BG = (25, 25, 25)
COLOR_SETTINGS_PANEL_BORDER = (90, 90, 90)
COLOR_SETTINGS_OVERLAY = (0, 0, 0, 180)  # затемнение игрового поля позади панели

SETTINGS_PANEL_WIDTH = 380
SETTINGS_PANEL_PADDING = 20
SETTINGS_PANEL_ROW_HEIGHT = 42
SETTINGS_PANEL_TITLE_HEIGHT = 50
SETTINGS_PANEL_TITLE = "НАСТРОЙКИ"

CHECKBOX_SIZE = 22
CHECKBOX_LABEL_GAP = 10
