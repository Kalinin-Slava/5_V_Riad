"""Константы, настройки по умолчанию, цветовая схема, размеры окна.

Все "пиксельные" размеры хранятся как BASE_* (эталон для десктопа) и пересчитываются
функцией configure(scale, ui_boost) в реальные CELL_SIZE/BUTTON_HEIGHT/... — десктоп
вызывает её один раз с scale=1.0 при импорте модуля (ничего не меняется), а мобильная
сборка пересчитывает эти же имена под реальный размер экрана телефона при старте.
`ui_boost` увеличивает кнопки/шрифты/HUD сильнее, чем саму доску — иначе на телефоне
интерфейс мельче, чем удобно нажимать пальцем.
"""

BASE_CELL_SIZE = 40
BASE_BOARD_MARGIN = 40

BASE_BUTTON_ROW_HEIGHT = 44
BASE_STATUS_ROW_HEIGHT = 40
BASE_BUTTON_HEIGHT = 32

DEFAULT_BOARD_SIZE = 15
MIN_BOARD_SIZE = 9
MAX_BOARD_SIZE = 25
WIN_LENGTH = 5

FPS = 60

COLOR_BACKGROUND = (0, 0, 0)
COLOR_GRID_LINE = (60, 60, 60)
COLOR_TEXT = (230, 230, 230)

COLOR_PLAYER_X = (60, 220, 255)   # неоновый голубой
COLOR_PLAYER_O = (255, 45, 170)   # неоновый розовый/малиновый

COLOR_HUD_BACKGROUND = (0, 0, 0)

BASE_WIN_LINE_WIDTH = 5
WIN_LINE_DARKEN_FACTOR = 0.7  # линия чуть темнее цвета фигур победителя

NEON_CORE_RADIUS_DIVISOR = 4  # радиус ядра символа = CELL_SIZE // это число

# Неоновое свечение: слои (доп. радиус в пикселях сверх ядра, альфа, толщина линии),
# от самого широкого/тусклого к самому узкому/яркому. Слои рисуются на поверхности
# размером ровно с клетку, поэтому свечение физически не может выйти за её пределы.
# Альфа (второе число) — прозрачность, не пиксели, масштабу не подлежит.
BASE_NEON_GLOW_LAYERS = [
    (6, 40, 6),
    (4, 80, 5),
    (2, 140, 4),
]
BASE_NEON_CORE_WIDTH = 3

MARK_TILE_DARKEN_FACTOR = 0.16  # подложка под фигурой = её цвет, затемнённый до этой доли

FONT_NAME = "consolas,couriernew,monospace"  # моноширинный "техно" шрифт (только десктоп)
BASE_FONT_SIZE_HUD = 30
BASE_FONT_SIZE_BUTTON = 18
COLOR_HUD_TEXT_SHADOW = (110, 110, 110)
BASE_HUD_TEXT_SHADOW_OFFSET = (3, 3)

# Кнопки верхней панели
BASE_BUTTON_ROW_LEFT_MARGIN = 10  # "Рестарт"/"Настройки" прижаты к левому краю окна
BASE_BUTTON_PADDING_X = 14
BASE_BUTTON_GAP = 8
BASE_BUTTON_BORDER_RADIUS = 6

COLOR_BUTTON_NEUTRAL = (40, 40, 40)
COLOR_BUTTON_NEUTRAL_TEXT = COLOR_TEXT

COLOR_UNDO_ICON = (235, 60, 60)  # красная стрелка "отменить ход" (только в игре с ботом)

COLOR_SURRENDER_TEXT = (15, 15, 15)  # тёмный текст на ярком неоновом фоне кнопки

COLOR_BUTTON_APPLY = (255, 195, 40)  # заметный акцент — есть несохранённое изменение настроек
COLOR_BUTTON_APPLY_TEXT = (20, 20, 20)

COLOR_DANGER_HIGHLIGHT = (255, 100, 0)  # предупреждающая рамка вокруг клеток с угрозой
BASE_DANGER_HIGHLIGHT_WIDTH = 2
BASE_DANGER_HIGHLIGHT_PADDING = 1  # на сколько рамка шире клетки

COLOR_BUTTON_EXIT = (30, 180, 90)
COLOR_BUTTON_EXIT_TEXT = (255, 255, 255)
COLOR_BUTTON_EXIT_GLOW = (120, 255, 170)
BASE_BUTTON_EXIT_GLOW_LAYERS = [
    (6, 35),
    (3, 70),
]

# Модальная панель настроек (шестерёнка в верхней панели)
COLOR_SETTINGS_PANEL_BG = (25, 25, 25)
COLOR_SETTINGS_PANEL_BORDER = (90, 90, 90)
COLOR_SETTINGS_OVERLAY = (0, 0, 0, 180)  # затемнение игрового поля позади панели

BASE_SETTINGS_PANEL_WIDTH = 380
BASE_SETTINGS_PANEL_PADDING = 20
BASE_SETTINGS_PANEL_ROW_HEIGHT = 42
BASE_SETTINGS_PANEL_TITLE_HEIGHT = 50
SETTINGS_PANEL_TITLE = "НАСТРОЙКИ"

BASE_CHECKBOX_SIZE = 22
BASE_CHECKBOX_LABEL_GAP = 10

UI_BOOST = 1.4  # насколько кнопки/шрифты/HUD крупнее самой доски на мобильной сборке


def _base_board_size_px(board_size):
    return BASE_BOARD_MARGIN * 2 + BASE_CELL_SIZE * board_size


def _base_hud_height():
    return BASE_BUTTON_ROW_HEIGHT + BASE_STATUS_ROW_HEIGHT


def compute_scale(screen_width, screen_height, board_size=DEFAULT_BOARD_SIZE, ui_boost=1.0):
    """Множитель масштаба, при котором доска+HUD (с учётом ui_boost на HUD)
    гарантированно поместятся в screen_width x screen_height без обрезки —
    берём меньший из масштабов по ширине и по высоте."""
    board_px = _base_board_size_px(board_size)
    if board_px <= 0 or screen_width <= 0 or screen_height <= 0:
        return 1.0

    scale_by_width = screen_width / board_px
    total_height_ratio = ui_boost * _base_hud_height() + board_px
    scale_by_height = screen_height / total_height_ratio

    return max(0.3, min(scale_by_width, scale_by_height))


def configure(scale=1.0, ui_boost=1.0):
    """Пересчитывает все пиксельные размеры из BASE_* с учётом масштаба.
    `ui_boost` применяется дополнительно только к HUD/кнопкам/шрифтам, не к доске."""
    global CELL_SIZE, BOARD_MARGIN
    global BUTTON_ROW_HEIGHT, STATUS_ROW_HEIGHT, BUTTON_HEIGHT, HUD_HEIGHT
    global WIN_LINE_WIDTH, WIN_LINE_EXTRA_LENGTH
    global NEON_GLOW_LAYERS, NEON_CORE_WIDTH
    global FONT_SIZE_HUD, FONT_SIZE_BUTTON, HUD_TEXT_SHADOW_OFFSET
    global BUTTON_TOP_Y, BUTTON_ROW_LEFT_MARGIN, BUTTON_PADDING_X, BUTTON_GAP, BUTTON_BORDER_RADIUS
    global DANGER_HIGHLIGHT_WIDTH, DANGER_HIGHLIGHT_PADDING
    global BUTTON_EXIT_GLOW_LAYERS
    global SETTINGS_PANEL_WIDTH, SETTINGS_PANEL_PADDING, SETTINGS_PANEL_ROW_HEIGHT, SETTINGS_PANEL_TITLE_HEIGHT
    global CHECKBOX_SIZE, CHECKBOX_LABEL_GAP

    def px(value):
        return max(1, round(value * scale))

    def ui_px(value):
        return max(1, round(value * scale * ui_boost))

    # Доска и всё, что должно оставаться пропорционально клетке, — без ui_boost
    CELL_SIZE = px(BASE_CELL_SIZE)
    BOARD_MARGIN = px(BASE_BOARD_MARGIN)
    WIN_LINE_WIDTH = px(BASE_WIN_LINE_WIDTH)
    WIN_LINE_EXTRA_LENGTH = CELL_SIZE
    NEON_GLOW_LAYERS = [(px(extra), alpha, px(width)) for extra, alpha, width in BASE_NEON_GLOW_LAYERS]
    NEON_CORE_WIDTH = px(BASE_NEON_CORE_WIDTH)
    DANGER_HIGHLIGHT_WIDTH = px(BASE_DANGER_HIGHLIGHT_WIDTH)
    DANGER_HIGHLIGHT_PADDING = px(BASE_DANGER_HIGHLIGHT_PADDING)

    # HUD, кнопки, шрифты, панель настроек — с ui_boost, крупнее доски
    BUTTON_ROW_HEIGHT = ui_px(BASE_BUTTON_ROW_HEIGHT)
    STATUS_ROW_HEIGHT = ui_px(BASE_STATUS_ROW_HEIGHT)
    BUTTON_HEIGHT = ui_px(BASE_BUTTON_HEIGHT)
    HUD_HEIGHT = BUTTON_ROW_HEIGHT + STATUS_ROW_HEIGHT

    FONT_SIZE_HUD = ui_px(BASE_FONT_SIZE_HUD)
    FONT_SIZE_BUTTON = ui_px(BASE_FONT_SIZE_BUTTON)
    HUD_TEXT_SHADOW_OFFSET = (ui_px(BASE_HUD_TEXT_SHADOW_OFFSET[0]), ui_px(BASE_HUD_TEXT_SHADOW_OFFSET[1]))

    BUTTON_ROW_LEFT_MARGIN = ui_px(BASE_BUTTON_ROW_LEFT_MARGIN)
    BUTTON_PADDING_X = ui_px(BASE_BUTTON_PADDING_X)
    BUTTON_GAP = ui_px(BASE_BUTTON_GAP)
    BUTTON_BORDER_RADIUS = ui_px(BASE_BUTTON_BORDER_RADIUS)
    BUTTON_TOP_Y = (BUTTON_ROW_HEIGHT - BUTTON_HEIGHT) // 2

    BUTTON_EXIT_GLOW_LAYERS = [(ui_px(extra), alpha) for extra, alpha in BASE_BUTTON_EXIT_GLOW_LAYERS]

    SETTINGS_PANEL_WIDTH = ui_px(BASE_SETTINGS_PANEL_WIDTH)
    SETTINGS_PANEL_PADDING = ui_px(BASE_SETTINGS_PANEL_PADDING)
    SETTINGS_PANEL_ROW_HEIGHT = ui_px(BASE_SETTINGS_PANEL_ROW_HEIGHT)
    SETTINGS_PANEL_TITLE_HEIGHT = ui_px(BASE_SETTINGS_PANEL_TITLE_HEIGHT)

    CHECKBOX_SIZE = ui_px(BASE_CHECKBOX_SIZE)
    CHECKBOX_LABEL_GAP = ui_px(BASE_CHECKBOX_LABEL_GAP)


configure(1.0, 1.0)  # значения по умолчанию — ровно то, что было раньше (для десктопа)
